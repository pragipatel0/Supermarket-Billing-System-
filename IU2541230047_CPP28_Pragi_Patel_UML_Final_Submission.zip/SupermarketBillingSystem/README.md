# Supermarket Billing System

Console-based C++ project prepared for Pragi Patel (Enrollment No. IU2541230047, CPP28).

## Build and run

From `src`:

```powershell
g++ -std=c++17 -Wall -Wextra main.cpp -o SupermarketBillingSystem.exe
.\SupermarketBillingSystem.exe
```

The application stores product data in `Data/products.txt`. It demonstrates CRUD operations, cart checkout, discount calculation, payment, dynamic memory, inheritance, runtime polymorphism, validation, exception handling and persistence.
