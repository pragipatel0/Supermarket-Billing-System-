#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;

class Displayable {
public:
    virtual ~Displayable() = default;
    virtual void display() const = 0;
};

class Product : public Displayable {
    int productId, stock; string name; double price;
public:
    Product() : productId(0), stock(0), price(0) {}
    Product(int id, string n, double p, int s) : productId(id), stock(s), name(n), price(p) {}
    virtual ~Product() = default;
    int id() const { return productId; } string getName() const { return name; } double getPrice() const { return price; } int getStock() const { return stock; }
    void update(string n, double p, int s) { if (p < 0 || s < 0) throw invalid_argument("Price and stock cannot be negative."); name=n; price=p; stock=s; }
    bool reduceStock(int qty) { if (qty < 1 || qty > stock) return false; stock -= qty; return true; }
    void display() const override { cout << left << setw(6) << productId << setw(22) << name << setw(10) << fixed << setprecision(2) << price << stock << '\n'; }
    string serialize() const { return to_string(productId)+"|"+name+"|"+to_string(price)+"|"+to_string(stock); }
};

class Customer : public Displayable {
    int customerId; string name, phone;
public:
    Customer(int id=0, string n="Walk-in Customer", string p="N/A") : customerId(id), name(n), phone(p) {}
    virtual ~Customer() = default;
    int id() const { return customerId; }
    void display() const override { cout << "Customer: " << name << " (" << phone << ")\n"; }
};

class Cart {
    int cartId, customerId; vector<pair<Product,int>> entries;
public:
    Cart(int id, int customer) : cartId(id), customerId(customer) {}
    virtual ~Cart() = default;
    bool addItem(Product& product, int quantity) { if (!product.reduceStock(quantity)) return false; entries.push_back({product, quantity}); return true; }
    double calculateTotal() const { double total=0; for (auto& e:entries) total += e.first.getPrice()*e.second; return total; }
    bool empty() const { return entries.empty(); } int id() const { return cartId; }
    const vector<pair<Product,int>>& items() const { return entries; }
};

class Bill {
    int billId, cartId; double subtotal, discount, total;
public:
    Bill(int id, const Cart& cart) : billId(id), cartId(cart.id()), subtotal(cart.calculateTotal()), discount(subtotal >= 1000 ? subtotal*0.05 : 0), total(subtotal-discount) {}
    virtual ~Bill() = default;
    double amount() const { return total; }
    void printBill(const Cart& cart) const { cout << "\n========== SUPERMARKET BILL ==========\nBill ID: " << billId << "  Cart ID: " << cartId << '\n'; for(auto& e:cart.items()) cout << "  " << e.first.getName() << " x " << e.second << " = Rs. " << fixed << setprecision(2) << e.first.getPrice()*e.second << '\n'; cout << "Subtotal: Rs. " << subtotal << "\nDiscount: Rs. " << discount << "\nTOTAL: Rs. " << total << "\n======================================\n"; }
};

class Payment : public Displayable {
    int paymentId, billId; double paid; string mode;
public:
    Payment(int p, int b, double a, string m) : paymentId(p), billId(b), paid(a), mode(m) {}
    virtual ~Payment() = default;
    virtual bool processPayment(double due) const { return paid >= due; }
    void display() const override { cout << "Payment " << paymentId << " accepted by " << mode << " for Rs. " << fixed << setprecision(2) << paid << '\n'; }
};

class FileManager {
public:
    void save(const vector<Product>& products, const string& path) const { ofstream out(path); if(!out) throw runtime_error("Unable to write data file."); for(auto& p:products) out << p.serialize() << '\n'; }
    vector<Product> load(const string& path) const { vector<Product> result; ifstream in(path); string line; while(getline(in,line)){ stringstream s(line); string id,n,price,stock; getline(s,id,'|'); getline(s,n,'|'); getline(s,price,'|'); getline(s,stock,'|'); if(!id.empty()) result.emplace_back(stoi(id),n,stod(price),stoi(stock)); } return result; }
};

class SupermarketSystem {
    Product* products; int count, capacity; FileManager files; const string dataFile="../Data/products.txt";
    void grow(){ capacity*=2; Product* bigger=new Product[capacity]; for(int i=0;i<count;i++) bigger[i]=products[i]; delete[] products; products=bigger; }
    Product* find(int id){ for(int i=0;i<count;i++) if(products[i].id()==id) return &products[i]; return nullptr; }
    int nextId() const { int maxId=0; for(int i=0;i<count;i++) maxId=max(maxId,products[i].id()); return maxId+1; }
    void printEntity(const Displayable& entity) const { entity.display(); }
public:
    SupermarketSystem() : products(new Product[10]), count(0), capacity(10) { load(); }
    ~SupermarketSystem(){ save(); delete[] products; }
    void load(){ for(auto& p:files.load(dataFile)){ if(count==capacity) grow(); products[count++]=p; } }
    void save() const { vector<Product> list(products,products+count); files.save(list,dataFile); }
    void add(){ string name; double price; int stock; cout<<"Product name: "; getline(cin>>ws,name); cout<<"Price: ";cin>>price; cout<<"Stock: ";cin>>stock; if(price<0||stock<0) throw invalid_argument("Price and stock cannot be negative."); if(count==capacity)grow(); products[count++]=Product(nextId(),name,price,stock); cout<<"Product added.\n"; }
    void display() const { cout<<"\nID    Product               Price     Stock\n"; for(int i=0;i<count;i++) printEntity(products[i]); }
    void search(){ int id;cout<<"Product ID: ";cin>>id; Product* p=find(id); if(p)p->display();else cout<<"Product not found.\n"; }
    void update(){ int id,stock;double price;string name;cout<<"Product ID: ";cin>>id;Product* p=find(id);if(!p){cout<<"Product not found.\n";return;}cout<<"New name: ";getline(cin>>ws,name);cout<<"New price: ";cin>>price;cout<<"New stock: ";cin>>stock;p->update(name,price,stock);cout<<"Product updated.\n"; }
    void remove(){ int id;cout<<"Product ID: ";cin>>id;int pos=-1;for(int i=0;i<count;i++)if(products[i].id()==id)pos=i;if(pos<0){cout<<"Product not found.\n";return;}for(int i=pos;i<count-1;i++)products[i]=products[i+1];count--;cout<<"Product deleted.\n"; }
    void checkout(){ if(count==0){cout<<"No products available.\n";return;} Customer customer(1);Cart cart(1001,customer.id());display();int id,qty;cout<<"Enter Product ID and quantity (0 to finish): ";while(cin>>id && id!=0){cin>>qty;Product* p=find(id);if(!p||!cart.addItem(*p,qty))cout<<"Invalid product or insufficient stock.\n";}if(cart.empty()){cout<<"Cart is empty.\n";return;}Bill bill(5001,cart);bill.printBill(cart);string mode;double amount;cout<<"Payment mode: ";getline(cin>>ws,mode);cout<<"Amount received: ";cin>>amount;Payment payment(9001,5001,amount,mode);if(payment.processPayment(bill.amount()))payment.display();else cout<<"Insufficient payment.\n"; }
};

int main(){ SupermarketSystem system; int choice; do { cout<<"\n--- SUPERMARKET BILLING SYSTEM ---\n1. Add Record\n2. Display Records\n3. Search Record\n4. Update Record\n5. Delete Record\n6. Checkout and Payment\n7. Save\n8. Exit\nChoice: "; if(!(cin>>choice)){cin.clear();cin.ignore(numeric_limits<streamsize>::max(),'\n');choice=0;} try{switch(choice){case 1:system.add();break;case 2:system.display();break;case 3:system.search();break;case 4:system.update();break;case 5:system.remove();break;case 6:system.checkout();break;case 7:system.save();cout<<"Data saved.\n";break;case 8:cout<<"Thank you.\n";break;default:cout<<"Choose an option from 1 to 8.\n";}}catch(const exception& e){cout<<"Error: "<<e.what()<<'\n';}}while(choice!=8); }
